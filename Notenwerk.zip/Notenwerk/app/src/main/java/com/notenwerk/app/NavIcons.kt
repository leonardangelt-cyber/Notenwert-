package com.notenwerk.app

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.unit.dp

/** Arten: 1 Fläche (weich -> voll), 2 Linie, 3 Zahl/Aussparung (Farbe wechselt beim Auswählen) */
class NavLayer(val d: String, val kind: Int)

private const val SQUARE = "M7 3.5 H17 A3.5 3.5 0 0 1 20.5 7 V17 A3.5 3.5 0 0 1 17 20.5 H7 A3.5 3.5 0 0 1 3.5 17 V7 A3.5 3.5 0 0 1 7 3.5 Z"

val navIconData: Map<Int, List<NavLayer>> = mapOf(
    // 1. Halbjahr
    0 to listOf(
        NavLayer(SQUARE, 1),
        NavLayer("M10.2 9.8 L12.6 8 V16.2", 3),
    ),
    // 2. Halbjahr
    1 to listOf(
        NavLayer(SQUARE, 1),
        NavLayer("M9.3 10.3 C9.3 7 14.7 7 14.7 10.3 C14.7 12.8 9.3 14 9.3 16.2 H14.9", 3),
    ),
    // Ende: Fahne
    2 to listOf(
        NavLayer("M6.5 4 V20.5", 2),
        NavLayer("M6.5 4.8 C9 3.6 11 6 13.5 5.2 C15.2 4.7 16.5 4.4 18 4.8 V12.6 C16.5 12.2 15.2 12.5 13.5 13 C11 13.8 9 11.4 6.5 12.6 Z", 1),
    ),
    // Einstellungen: Regler
    3 to listOf(
        NavLayer("M4 7 H6 M12 7 H20 M4 12 H12.5 M18.5 12 H20 M4 17 H5.5 M11.5 17 H20", 2),
        NavLayer("M6 7 A3 3 0 1 0 12 7 A3 3 0 1 0 6 7 Z", 1),
        NavLayer("M12.5 12 A3 3 0 1 0 18.5 12 A3 3 0 1 0 12.5 12 Z", 1),
        NavLayer("M5.5 17 A3 3 0 1 0 11.5 17 A3 3 0 1 0 5.5 17 Z", 1),
    ),
)

/** Selbst gezeichnetes Symbol für die untere Leiste, im Stil der Fach-Symbole. */
@Composable
fun NavIcon(idx: Int, selected: Boolean) {
    val fg = LocalContentColor.current
    val cut = MaterialTheme.colorScheme.secondaryContainer
    val sel by animateFloatAsState(
        if (selected) 1f else 0f,
        MaterialTheme.motionScheme.defaultEffectsSpec(),
        label = "navSel",
    )
    val grow by animateFloatAsState(
        if (selected) 1.1f else 1f,
        MaterialTheme.motionScheme.fastSpatialSpec(),
        label = "navGrow",
    )
    val layers = navIconData.getValue(idx)
    val paths = remember(idx) { layers.map { PathParser().parsePathString(it.d).toPath() } }
    Canvas(
        Modifier
            .size(24.dp)
            .graphicsLayer { scaleX = grow; scaleY = grow }
    ) {
        val s = size.minDimension / 24f
        scale(s, Offset.Zero) {
            for (i in layers.indices) {
                when (layers[i].kind) {
                    1 -> drawPath(paths[i], fg.copy(alpha = 0.38f + 0.62f * sel))
                    2 -> drawPath(paths[i], fg, style = Stroke(2.2f, cap = StrokeCap.Round, join = StrokeJoin.Round))
                    else -> drawPath(paths[i], lerp(fg, cut, sel), style = Stroke(2.2f, cap = StrokeCap.Round, join = StrokeJoin.Round))
                }
            }
        }
    }
}
