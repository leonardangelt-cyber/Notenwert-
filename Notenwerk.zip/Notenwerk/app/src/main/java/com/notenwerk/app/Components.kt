@file:OptIn(ExperimentalMaterial3ExpressiveApi::class)

package com.notenwerk.app

import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Apartment
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.ChildCare
import androidx.compose.material.icons.filled.Computer
import androidx.compose.material.icons.filled.Eco
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.NightsStay
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.SportsSoccer
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialShapes
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.toShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.util.Locale
import kotlin.math.min

// ---------------------------------------------------------------- Zahlen & Farben

fun fmt(d: Double?): String = if (d == null) "–" else String.format(Locale.GERMANY, "%.1f", d)

private val gradeStops = listOf(
    Color(0xFF00A800), // 1
    Color(0xFF55A800), // 2
    Color(0xFF8AAA00), // 3
    Color(0xFFD4B21C), // 4
    Color(0xFFFF9F0A), // 5
    Color(0xFFF44336), // 6
)

fun gradeColor(v: Double): Color {
    val x = v.coerceIn(1.0, 6.0) - 1.0
    val i = min(x.toInt(), 4)
    return lerp(gradeStops[i], gradeStops[i + 1], (x - i).toFloat())
}

fun gradeLabel(g: Grade): String {
    val base = if (g.value % 1.0 == 0.0) g.value.toInt().toString() else fmt(g.value)
    return base + when (g.tendency) {
        1 -> "+"
        -1 -> "-"
        else -> ""
    }
}

// ---------------------------------------------------------------- Formen

fun segmentShape(i: Int, n: Int): Shape {
    val big = 28.dp
    val small = 6.dp
    val top = if (i == 0) big else small
    val bottom = if (i == n - 1) big else small
    return RoundedCornerShape(topStart = top, topEnd = top, bottomStart = bottom, bottomEnd = bottom)
}

// ---------------------------------------------------------------- Bewegung

/** Skalierung beim Drücken (Spring aus dem Expressive-MotionScheme) + Form + Ripple. */
@Composable
fun Modifier.bouncy(
    shape: Shape,
    color: Color = Color.Transparent,
    enabled: Boolean = true,
    onClick: () -> Unit,
): Modifier {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val s by animateFloatAsState(
        targetValue = if (pressed) 0.95f else 1f,
        animationSpec = MaterialTheme.motionScheme.fastSpatialSpec(),
        label = "press",
    )
    return this
        .graphicsLayer { scaleX = s; scaleY = s }
        .clip(shape)
        .background(color)
        .clickable(
            interactionSource = source,
            indication = LocalIndication.current,
            enabled = enabled,
            onClick = onClick,
        )
}

/** Gestaffeltes Einblenden von Listeneinträgen. */
@Composable
fun Modifier.staggerIn(index: Int): Modifier {
    val a = remember { Animatable(0f) }
    val spec = MaterialTheme.motionScheme.defaultSpatialSpec<Float>()
    LaunchedEffect(Unit) {
        delay(min(index, 8) * 45L)
        a.animateTo(1f, spec)
    }
    return this.graphicsLayer {
        alpha = a.value.coerceIn(0f, 1f)
        translationY = (1f - a.value) * 70f
    }
}

/** Kachel, deren Ecken beim Drücken/Auswählen „morphen“. */
@Composable
fun MorphTile(
    modifier: Modifier = Modifier,
    color: Color,
    selected: Boolean = false,
    baseRadius: Dp = 22.dp,
    activeRadius: Dp = 50.dp,
    onClick: () -> Unit,
    content: @Composable () -> Unit,
) {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val m = MaterialTheme.motionScheme
    val r by animateDpAsState(
        targetValue = if (pressed || selected) activeRadius else baseRadius,
        animationSpec = m.defaultSpatialSpec(),
        label = "radius",
    )
    val sc by animateFloatAsState(
        targetValue = if (pressed) 0.92f else 1f,
        animationSpec = m.fastSpatialSpec(),
        label = "tileScale",
    )
    val bg by animateColorAsState(color, m.defaultEffectsSpec(), label = "tileColor")
    Box(
        modifier
            .graphicsLayer { scaleX = sc; scaleY = sc }
            .clip(RoundedCornerShape(r.coerceAtLeast(0.dp)))
            .background(bg)
            .clickable(interactionSource = source, indication = LocalIndication.current, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { content() }
}

// ---------------------------------------------------------------- Bausteine

@Composable
fun GradeBubble(avg: Double?, size: Dp, modifier: Modifier = Modifier) {
    val target = avg?.let { gradeColor(it) } ?: MaterialTheme.colorScheme.surfaceContainerHighest
    val color by animateColorAsState(target, tween(600), label = "bubble")
    val cookie9 = MaterialShapes.Cookie9Sided.toShape()
    Box(
        modifier
            .size(size)
            .clip(cookie9)
            .background(color),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = fmt(avg),
            color = if (avg == null) MaterialTheme.colorScheme.onSurfaceVariant else Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = (size.value * 0.34f).sp,
        )
    }
}

@Composable
fun BadgeChip(text: String, avg: Double) {
    Box(
        Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(gradeColor(avg))
            .padding(horizontal = 8.dp, vertical = 2.dp)
    ) {
        Text(text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
    }
}

@Composable
fun Hero(avg: Double?, caption: String) {
    val animated by animateFloatAsState(
        targetValue = (avg ?: 0.0).toFloat(),
        animationSpec = tween(900, easing = FastOutSlowInEasing),
        label = "heroNumber",
    )
    val color by animateColorAsState(
        targetValue = avg?.let { gradeColor(it) } ?: MaterialTheme.colorScheme.surfaceContainerHighest,
        animationSpec = tween(700),
        label = "heroColor",
    )
    val shapes = listOf(
        MaterialShapes.Cookie9Sided,
        MaterialShapes.Cookie12Sided,
        MaterialShapes.SoftBurst,
        MaterialShapes.Clover4Leaf,
        MaterialShapes.Flower,
    ).map { it.toShape() }
    val idx = when {
        avg == null -> 0
        avg < 1.7 -> 1
        avg < 2.7 -> 0
        avg < 3.7 -> 4
        avg < 4.7 -> 3
        else -> 2
    }
    val infinite = rememberInfiniteTransition(label = "spin")
    val rot by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(36000, easing = LinearEasing), RepeatMode.Restart),
        label = "rot",
    )
    val pop = remember { Animatable(0.8f) }
    LaunchedEffect(avg) {
        pop.snapTo(0.82f)
        pop.animateTo(1f, spring(dampingRatio = 0.42f, stiffness = Spring.StiffnessLow))
    }

    Column(
        Modifier
            .fillMaxWidth()
            .padding(top = 8.dp, bottom = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(Modifier.size(220.dp), contentAlignment = Alignment.Center) {
            Crossfade(targetState = idx, animationSpec = tween(700), label = "heroShape") { i ->
                Box(
                    Modifier
                        .fillMaxSize()
                        .graphicsLayer {
                            rotationZ = rot
                            scaleX = pop.value
                            scaleY = pop.value
                        }
                        .clip(shapes[i])
                        .background(color)
                )
            }
            Text(
                text = if (avg == null) "–" else fmt(animated.toDouble()),
                color = if (avg == null) MaterialTheme.colorScheme.onSurfaceVariant else Color.White,
                style = MaterialTheme.typography.displayLarge,
                fontWeight = FontWeight.Bold,
                fontSize = 64.sp,
            )
        }
        Spacer(Modifier.height(12.dp))
        Text(
            text = caption,
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.SemiBold,
            letterSpacing = 4.sp,
            textAlign = TextAlign.Center,
        )
    }
}

@Composable
fun SubjectRow(
    name: String,
    avg: Double?,
    badge: String?,
    subtitle: String?,
    shape: Shape,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    Row(
        modifier
            .fillMaxWidth()
            .bouncy(shape, MaterialTheme.colorScheme.surfaceContainer, onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        SubjectBadge(name, 52.dp)
        Spacer(Modifier.size(16.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
            if (badge != null && avg != null) BadgeChip(badge, avg)
            if (subtitle != null) {
                Text(
                    subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        GradeBubble(avg, 60.dp)
    }
}

@Composable
fun ContainerCard(
    title: String,
    icon: ImageVector,
    modifier: Modifier = Modifier,
    trailing: @Composable (() -> Unit)? = null,
    content: @Composable () -> Unit,
) {
    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(28.dp))
            .background(MaterialTheme.colorScheme.surfaceContainerHigh)
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.onSurface)
            Spacer(Modifier.size(12.dp))
            Text(
                title,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.weight(1f),
            )
            trailing?.invoke()
        }
        content()
    }
}
