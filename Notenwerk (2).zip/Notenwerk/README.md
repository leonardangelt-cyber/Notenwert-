# Notenwerk

Notentracker im Stil von Material 3 Expressive (Jetpack Compose).

## APK über GitHub bauen
1. Neues Repository anlegen und den **Inhalt** dieses Ordners hochladen (inkl. `.github/workflows/build.yml`).
2. Auf GitHub: **Actions → Build APK** (läuft automatisch bei jedem Push, oder „Run workflow").
3. Nach dem Lauf: Releases → neueste Version → Notenwerk.apk installieren (Sprachpakete lang-*.json hängen am Release; das Repo muss öffentlich sein).
