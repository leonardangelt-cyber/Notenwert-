@file:OptIn(ExperimentalMaterial3ExpressiveApi::class, ExperimentalLayoutApi::class)

package com.notenwerk.app

import androidx.compose.animation.AnimatedContent
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.EmojiEvents
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.LooksOne
import androidx.compose.material.icons.filled.LooksTwo
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Straighten
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.FilterChip
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialShapes
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.toShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.UUID
import kotlin.math.roundToInt

// ======================================================================= Home

@Composable
fun HomeShell(vm: AppVM) {
    val m = MaterialTheme.motionScheme
    val spatial = m.defaultSpatialSpec<IntOffset>()
    val effects = m.defaultEffectsSpec<Float>()

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surfaceContainer) {
                listOf("1. HJ", "2. HJ", "Ende", "Einst.").forEachIndexed { i, label ->
                    val sel = vm.tab == i
                    NavigationBarItem(
                        selected = sel,
                        onClick = { vm.tab = i },
                        icon = {
                            NavIconBox(sel) {
                                when (i) {
                                    0 -> NavNumber(1, sel)
                                    1 -> NavNumber(2, sel)
                                    2 -> Icon(if (sel) Icons.Filled.EmojiEvents else Icons.Outlined.EmojiEvents, null)
                                    else -> Icon(if (sel) Icons.Filled.Settings else Icons.Outlined.Settings, null)
                                }
                            }
                        },
                        label = { Text(label, fontWeight = if (sel) FontWeight.Bold else FontWeight.Medium) },
                    )
                }
            }
        },
    ) { pad ->
        AnimatedContent(
            targetState = vm.tab,
            transitionSpec = {
                val dir = if (targetState > initialState) 1 else -1
                (slideInHorizontally(spatial) { it / 4 * dir } + fadeIn(effects)) togetherWith
                        (slideOutHorizontally(spatial) { -it / 4 * dir } + fadeOut(effects))
            },
            label = "tabs",
        ) { tab ->
            when (tab) {
                0 -> SemesterPage(vm, 1, pad)
                1 -> SemesterPage(vm, 2, pad)
                2 -> EndPage(vm, pad)
                else -> SettingsPage(vm, pad)
            }
        }
    }
}

/** Icon, das beim Auswählen mit einer Feder-Animation leicht wächst. */
@Composable
private fun NavIconBox(selected: Boolean, content: @Composable () -> Unit) {
    val sc by animateFloatAsState(
        targetValue = if (selected) 1.15f else 1f,
        animationSpec = MaterialTheme.motionScheme.fastSpatialSpec(),
        label = "navScale",
    )
    Box(Modifier.graphicsLayer { scaleX = sc; scaleY = sc }) { content() }
}

/** Ziffer in einer expressiven Form statt eines eckigen Standard-Icons. */
@Composable
private fun NavNumber(n: Int, selected: Boolean) {
    val cs = MaterialTheme.colorScheme
    val effects = MaterialTheme.motionScheme.defaultEffectsSpec<Color>()
    val bg by animateColorAsState(if (selected) cs.primary else cs.surfaceContainerHighest, effects, label = "navBg")
    val fg by animateColorAsState(if (selected) cs.onPrimary else cs.onSurfaceVariant, effects, label = "navFg")
    Box(
        Modifier
            .size(30.dp)
            .clip(MaterialShapes.Cookie6Sided.toShape())
            .background(bg),
        contentAlignment = Alignment.Center,
    ) {
        Text("$n", color = fg, fontWeight = FontWeight.Bold, fontSize = 15.sp)
    }
}

private fun listPadding(pad: PaddingValues) = PaddingValues(
    start = 16.dp,
    end = 16.dp,
    top = pad.calculateTopPadding() + 8.dp,
    bottom = pad.calculateBottomPadding() + 24.dp,
)

@Composable
private fun TitleBar(title: String, onAdd: (() -> Unit)? = null, onDecimal: (() -> Unit)? = null) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            title,
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.weight(1f),
        )
        if (onDecimal != null) {
            FilledTonalIconButton(onClick = onDecimal) { Icon(Icons.Filled.Straighten, "Nachkommastellen") }
            Spacer(Modifier.width(8.dp))
        }
        if (onAdd != null) {
            FilledTonalIconButton(onClick = onAdd) { Icon(Icons.Filled.Add, "Fach hinzufügen") }
        }
    }
}

@Composable
private fun EmptyHint(text: String) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 32.dp, horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Box(
            Modifier
                .size(96.dp)
                .clip(MaterialShapes.Cookie12Sided.toShape())
                .background(MaterialTheme.colorScheme.tertiaryContainer),
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Filled.School, null, tint = MaterialTheme.colorScheme.onTertiaryContainer, modifier = Modifier.size(44.dp))
        }
        Text(
            text,
            style = MaterialTheme.typography.bodyLarge,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
fun SemesterPage(vm: AppVM, sem: Int, pad: PaddingValues) {
    val subs = vm.subjects.filter { sem in it.sems }
    val overall = vm.semAvg(sem)
    val seen = remember { Intro() }
    var showDecimal by rememberSaveable { mutableStateOf(false) }
    if (showDecimal) PlacesDialog(vm) { showDecimal = false }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = listPadding(pad),
        verticalArrangement = Arrangement.spacedBy(3.dp),
    ) {
        item(key = "title") { TitleBar("Notenwerk", onAdd = { vm.push(Route.AddSubject(sem)) }, onDecimal = { showDecimal = true }) }
        item(key = "hero") { Hero(overall, "$sem. Halbjahr") }
        itemsIndexed(subs, key = { _, s -> s.id }) { i, s ->
            SubjectRow(
                name = s.name,
                avg = vm.avg(s, sem),
                badge = vm.badge(s, sem),
                subtitle = null,
                shape = segmentShape(i, subs.size),
                modifier = Modifier
                    .animateItem()
                    .staggerIn(i, seen, s.id),
            ) { vm.push(Route.SubjectDetail(s.id, sem)) }
        }
        if (subs.isEmpty()) {
            item(key = "empty") { EmptyHint("Noch keine Fächer.\nTippe oben auf + und füge dein erstes Fach hinzu.") }
        }
    }
}

@Composable
fun EndPage(vm: AppVM, pad: PaddingValues) {
    val seen = remember { Intro() }
    val places = LocalDecimals.current
    val subs = vm.subjects.filter { vm.yearAvg(it) != null }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = listPadding(pad),
        verticalArrangement = Arrangement.spacedBy(3.dp),
    ) {
        item(key = "title") { TitleBar("Notenwerk", null) }
        item(key = "hero") { Hero(vm.overallYear(), "Ende") }
        itemsIndexed(subs, key = { _, s -> s.id }) { i, s ->
            val parts = s.sems.sorted().mapNotNull { sem -> vm.avg(s, sem)?.let { "$sem. HJ ${fmt(it, places)}" } }
            val a = vm.yearAvg(s)
            SubjectRow(
                name = s.name,
                avg = a,
                badge = a?.let { badgeText(it) },
                subtitle = parts.joinToString("  ·  "),
                shape = segmentShape(i, subs.size),
                modifier = Modifier
                    .animateItem()
                    .staggerIn(i, seen, s.id),
            ) { }
        }
        if (subs.isEmpty()) {
            item(key = "empty") { EmptyHint("Sobald du Noten einträgst, siehst du hier deinen Jahresschnitt.") }
        }
    }
}

// ======================================================================= Nachkommastellen (Lineal)

@Composable
fun PlacesDialog(vm: AppVM, onDismiss: () -> Unit) {
    val example = fmt(2.53333, vm.decimals)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Nachkommastellen") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Text("Wie viele Stellen nach dem Komma sollen bei Durchschnitten angezeigt werden?")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    (0..3).forEach { n ->
                        val sel = vm.decimals == n
                        MorphTile(
                            modifier = Modifier
                                .weight(1f)
                                .height(56.dp),
                            color = if (sel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceContainerHighest,
                            selected = sel,
                            baseRadius = 14.dp,
                            activeRadius = 28.dp,
                            onClick = { vm.updateDecimals(n) },
                        ) {
                            Text(
                                "$n",
                                color = if (sel) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                                fontWeight = FontWeight.Bold,
                                fontSize = 22.sp,
                            )
                        }
                    }
                }
                Text(
                    "Beispiel: $example",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                )
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Fertig") } },
    )
}

// ======================================================================= Einstellungen

@Composable
fun SettingsPage(vm: AppVM, pad: PaddingValues) {
    var confirmReset by rememberSaveable { mutableStateOf(false) }
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(listPadding(pad)),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        TitleBar("Einstellungen", null)

        ContainerCard("Design", Icons.Filled.Tune) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("System", "Hell", "Dunkel").forEachIndexed { i, label ->
                    val sel = vm.themeMode == i
                    MorphTile(
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp),
                        color = if (sel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceContainerHighest,
                        selected = sel,
                        baseRadius = 14.dp,
                        activeRadius = 26.dp,
                        onClick = { vm.updateThemeMode(i) },
                    ) {
                        Text(
                            label,
                            color = if (sel) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                            fontWeight = FontWeight.Medium,
                        )
                    }
                }
            }
            SwitchRow("Dynamische Farben (Material You)", vm.dynamicColor) { vm.setDynamic(it) }
        }

        ContainerCard("Noten", Icons.Filled.Edit) {
            SwitchRow("+ / - beim Eintragen anbieten", vm.tendencyDefault) { vm.updateTendencyDefault(it) }
            SwitchRow("Tendenz in den Schnitt einrechnen (±0,33)", vm.tendencyCounts) { vm.updateTendencyCounts(it) }
        }

        ContainerCard("Daten", Icons.Filled.Delete) {
            FilledTonalButton(onClick = { confirmReset = true }) {
                Icon(Icons.Filled.Delete, null)
                Spacer(Modifier.width(8.dp))
                Text("Alle Daten löschen")
            }
        }
    }
    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("Alle Daten löschen?") },
            text = { Text("Alle Fächer und Noten werden unwiderruflich entfernt.") },
            confirmButton = {
                TextButton(onClick = { vm.resetAll(); confirmReset = false }) { Text("Löschen") }
            },
            dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("Abbrechen") } },
        )
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
        Spacer(Modifier.width(12.dp))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

// ======================================================================= Fach hinzufügen

private val suggestions = listOf(
    "Architektur", "Astronomie", "BWL", "BWR", "Biologie", "Chemie", "Chinesisch", "Chor",
    "Darstellendes Spiel", "Deutsch", "Englisch", "Erdkunde", "Ernährung", "Erziehung",
    "Ethik", "Evang. Religion", "Französisch", "GRW", "Gemeinschaftskunde", "Geographie",
    "Geschichte", "Gesellschaftslehre", "Gesundheit", "Griechisch", "Hauswirtschaft",
    "Informatik", "Italienisch", "Japanisch", "Kath. Religion", "Kochen", "Kunst", "Latein",
    "Literatur", "Mathematik", "Medien", "Musik", "NWT", "Naturwissenschaften",
    "Niederländisch", "P-Seminar", "Philosophie", "Physik", "Politik",
    "Politik und Gesellschaft", "Politik und Wirtschaft", "Psychologie", "Pädagogik",
    "Rechnungswesen", "Recht", "Rechtskunde", "Religion", "Rhetorik", "Russisch",
    "Seminarfach", "Seminarkurs", "Sozialkunde", "Sozialwissenschaften", "Soziologie",
    "Spanisch", "Sport", "Technik", "Theater", "Türkisch", "VWL", "W-Seminar", "Werken",
    "Werte und Normen", "Wirtschaft", "Wirtschaft und Recht",
)

@Composable
fun BackHeader(title: String, onBack: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Zurück") }
        Spacer(Modifier.width(12.dp))
        Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun AddSubjectScreen(vm: AppVM) {
    val seen = remember { Intro() }
    var s1 by rememberSaveable { mutableStateOf(true) }
    var s2 by rememberSaveable { mutableStateOf(true) }
    var text by rememberSaveable { mutableStateOf("") }
    val sel = buildSet { if (s1) add(1); if (s2) add(2) }

    fun submit() {
        if (text.isNotBlank() && sel.isNotEmpty()) {
            vm.addSubject(text, sel)
            text = ""
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        BackHeader("Neues Fach") { vm.pop() }

        Row(
            Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text("Halbjahre:", style = MaterialTheme.typography.bodyLarge)
            listOf(1 to s1, 2 to s2).forEach { (n, on) ->
                MorphTile(
                    modifier = Modifier
                        .width(56.dp)
                        .height(40.dp),
                    color = if (on) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceContainerHighest,
                    selected = on,
                    baseRadius = 12.dp,
                    activeRadius = 20.dp,
                    onClick = { if (n == 1) s1 = !s1 else s2 = !s2 },
                ) {
                    Text(
                        "$n",
                        color = if (on) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                        fontWeight = FontWeight.Bold,
                    )
                }
            }
        }

        Row(
            Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            TextField(
                value = text,
                onValueChange = { text = it },
                modifier = Modifier.weight(1f),
                singleLine = true,
                placeholder = { Text("Fach eingeben…") },
                shape = RoundedCornerShape(20.dp),
                colors = TextFieldDefaults.colors(
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    disabledIndicatorColor = Color.Transparent,
                ),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { submit() }),
            )
            FilledIconButton(
                onClick = { submit() },
                enabled = text.isNotBlank() && sel.isNotEmpty(),
                modifier = Modifier.size(56.dp),
            ) { Icon(Icons.Filled.Check, "Hinzufügen") }
        }

        Text(
            "Vorschläge",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
        )

        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 24.dp)) {
            itemsIndexed(suggestions, key = { _, n -> n }) { i, name ->
                val added = sel.isNotEmpty() && vm.subjects.any {
                    it.name.equals(name, ignoreCase = true) && it.sems.containsAll(sel)
                }
                Row(
                    Modifier
                        .fillMaxWidth()
                        .bouncy(RoundedCornerShape(20.dp)) {
                            if (!added) vm.addSubject(name, sel)
                        }
                        .padding(horizontal = 20.dp, vertical = 14.dp)
                        .staggerIn(i, seen, name),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    SubjectBadge(name, 44.dp)
                    Spacer(Modifier.width(20.dp))
                    Text(name, style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.width(12.dp))
                    AnimatedVisibility(
                        visible = added,
                        enter = scaleIn(MaterialTheme.motionScheme.defaultSpatialSpec(), initialScale = 0.2f) + fadeIn(),
                        exit = scaleOut() + fadeOut(),
                    ) {
                        Box(
                            Modifier
                                .size(28.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(Icons.Filled.Check, null, tint = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
        }
    }
}

// ======================================================================= Fach-Detail

@Composable
fun SubjectScreen(vm: AppVM, id: String, sem: Int) {
    val live = vm.subjects.firstOrNull { it.id == id }
    val keep = remember { mutableStateOf(live) }
    if (live != null) keep.value = live
    val subject = keep.value ?: return

    var rename by rememberSaveable { mutableStateOf(false) }
    var groups by rememberSaveable { mutableStateOf(false) }
    var delete by rememberSaveable { mutableStateOf(false) }

    val avg = vm.avg(subject, sem)
    val badge = vm.badge(subject, sem)

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        BackHeader("$sem. Halbjahr") { vm.pop() }
        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Row(Modifier.padding(horizontal = 4.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                SubjectBadge(subject.name, 52.dp)
                Spacer(Modifier.width(16.dp))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(subject.name, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
                    if (badge != null && avg != null) BadgeChip(badge, avg)
                }
                GradeBubble(avg, 72.dp)
            }

            GroupCard("Klassenarbeiten", Icons.Filled.School, subject.examPct, vm.gradesOf(id, sem, 3), vm,
                onAdd = { vm.push(Route.Entry(id, sem, 3, null)) },
                onEdit = { vm.push(Route.Entry(id, sem, 3, it)) })
            GroupCard("schriftliche Noten", Icons.Filled.Edit, subject.writtenPct, vm.gradesOf(id, sem, 0), vm,
                onAdd = { vm.push(Route.Entry(id, sem, 0, null)) },
                onEdit = { vm.push(Route.Entry(id, sem, 0, it)) })
            GroupCard("mündliche Noten", Icons.Filled.Groups, (100 - subject.writtenPct - subject.examPct).coerceAtLeast(0), vm.gradesOf(id, sem, 1), vm,
                onAdd = { vm.push(Route.Entry(id, sem, 1, null)) },
                onEdit = { vm.push(Route.Entry(id, sem, 1, it)) })

            ContainerCard("Note festlegen", Icons.Filled.Check) {
                val fin = subject.finals[sem]
                MorphTile(
                    Modifier
                        .width(72.dp)
                        .height(60.dp),
                    color = fin?.let { gradeColor(it) } ?: Color(0xFFA0A0A0),
                    onClick = { vm.push(Route.Entry(id, sem, 2, null)) },
                ) {
                    Text(
                        fin?.let { if (it % 1.0 == 0.0) it.toInt().toString() else fmt(it) } ?: "-",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 20.sp,
                    )
                }
            }
        }

        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
        ) {
            ActionItem("Fach", Icons.Filled.Edit) { rename = true }
            ActionItem("Gruppen", Icons.Filled.Tune) { groups = true }
            ActionItem("Löschen", Icons.Filled.Delete) { delete = true }
        }
    }

    if (rename) {
        var name by remember { mutableStateOf(subject.name) }
        AlertDialog(
            onDismissRequest = { rename = false },
            title = { Text("Fach umbenennen") },
            text = { TextField(name, { name = it }, singleLine = true) },
            confirmButton = { TextButton(onClick = { vm.renameSubject(id, name); rename = false }) { Text("Speichern") } },
            dismissButton = { TextButton(onClick = { rename = false }) { Text("Abbrechen") } },
        )
    }
    if (groups) {
        var exam by remember { mutableFloatStateOf(subject.examPct.toFloat()) }
        var written by remember { mutableFloatStateOf(subject.writtenPct.toFloat()) }
        val oral = (100 - exam.roundToInt() - written.roundToInt()).coerceAtLeast(0)
        AlertDialog(
            onDismissRequest = { groups = false },
            title = { Text("Gewichtung der Gruppen") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Klassenarbeiten ${exam.roundToInt()} %")
                    Slider(
                        value = exam,
                        onValueChange = {
                            exam = (it / 5f).roundToInt() * 5f
                            if (written > 100f - exam) written = 100f - exam
                        },
                        valueRange = 0f..100f, steps = 19,
                    )
                    Text("schriftlich ${written.roundToInt()} %")
                    Slider(
                        value = written,
                        onValueChange = { written = ((it / 5f).roundToInt() * 5f).coerceAtMost(100f - exam) },
                        valueRange = 0f..100f, steps = 19,
                    )
                    Text("mündlich $oral %", fontWeight = FontWeight.SemiBold)
                }
            },
            confirmButton = {
                TextButton(onClick = { vm.setGroups(id, written.roundToInt(), exam.roundToInt()); groups = false }) { Text("Speichern") }
            },
            dismissButton = { TextButton(onClick = { groups = false }) { Text("Abbrechen") } },
        )
    }
    if (delete) {
        AlertDialog(
            onDismissRequest = { delete = false },
            title = { Text("${subject.name} löschen?") },
            text = { Text("Das Fach und alle zugehörigen Noten werden entfernt.") },
            confirmButton = {
                TextButton(onClick = { delete = false; vm.pop(); vm.deleteSubject(id) }) { Text("Löschen") }
            },
            dismissButton = { TextButton(onClick = { delete = false }) { Text("Abbrechen") } },
        )
    }
}

@Composable
private fun ActionItem(label: String, icon: ImageVector, onClick: () -> Unit) {
    Column(
        Modifier
            .bouncy(RoundedCornerShape(20.dp), onClick = onClick)
            .padding(horizontal = 24.dp, vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        Icon(icon, null)
        Text(label, style = MaterialTheme.typography.titleMedium)
    }
}

@Composable
private fun GroupCard(
    title: String,
    icon: ImageVector,
    pct: Int,
    grades: List<Grade>,
    vm: AppVM,
    onAdd: () -> Unit,
    onEdit: (String) -> Unit,
) {
    ContainerCard(
        title, icon,
        trailing = {
            Text("$pct %", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        },
    ) {
        FlowRow(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            grades.forEach { g ->
                MorphTile(
                    Modifier
                        .width(68.dp)
                        .height(60.dp),
                    color = gradeColor(vm.effective(g)),
                    onClick = { onEdit(g.id) },
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(gradeLabel(g), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                        if (g.weight > 1) Text("×${g.weight}", color = Color.White.copy(alpha = 0.85f), fontSize = 11.sp)
                    }
                }
            }
            MorphTile(
                Modifier.size(60.dp),
                color = MaterialTheme.colorScheme.primary,
                baseRadius = 30.dp,
                activeRadius = 18.dp,
                onClick = onAdd,
            ) { Icon(Icons.Filled.Add, "Note hinzufügen", tint = MaterialTheme.colorScheme.onPrimary) }
        }
    }
}

// ======================================================================= Note eintragen

@Composable
fun EntryScreen(vm: AppVM, r: Route.Entry) {
    val subject = vm.subjects.firstOrNull { it.id == r.subjectId }
    val keep = remember { mutableStateOf(subject) }
    if (subject != null) keep.value = subject
    val sub = keep.value ?: return
    val existing = r.gradeId?.let { gid -> vm.grades.firstOrNull { it.id == gid } }

    var tendencyOn by rememberSaveable { mutableStateOf(vm.tendencyDefault) }
    var comma by rememberSaveable { mutableStateOf(false) }
    var weightOn by rememberSaveable { mutableStateOf((existing?.weight ?: 1) > 1) }
    var weight by rememberSaveable { mutableIntStateOf(existing?.weight ?: 1) }
    var picked by rememberSaveable { mutableIntStateOf(0) } // 0 = noch nichts gewählt
    var slider by rememberSaveable { mutableFloatStateOf((existing?.value ?: 2.5).toFloat()) }

    val kindName = when (r.kind) {
        0 -> "schriftliche Noten"
        1 -> "mündliche Noten"
        3 -> "Klassenarbeiten"
        else -> "Note festlegen"
    }

    fun commit(value: Double, tend: Int) {
        if (r.kind == 2) {
            vm.setFinal(r.subjectId, r.sem, value)
        } else {
            vm.saveGrade(
                Grade(
                    id = existing?.id ?: UUID.randomUUID().toString(),
                    subjectId = r.subjectId, sem = r.sem, kind = r.kind,
                    value = value, tendency = tend, weight = if (weightOn) weight else 1,
                )
            )
        }
        vm.pop()
    }

    val m = MaterialTheme.motionScheme
    val sp = m.defaultSpatialSpec<Float>()
    val ef = m.defaultEffectsSpec<Float>()

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        BackHeader("Note") { vm.pop() }
        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Text(
                "${sub.name} / $kindName",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 16.dp),
            )

            ContainerCard(
                "Note auswählen", Icons.Filled.Check,
                trailing = {
                    AnimatedVisibility(visible = picked != 0, enter = scaleIn(sp) + fadeIn(ef), exit = scaleOut() + fadeOut()) {
                        IconButton(onClick = { picked = 0 }) { Icon(Icons.Filled.Close, "Zurück") }
                    }
                },
            ) {
                val mode = if (comma) 2 else if (picked != 0) 1 else 0
                AnimatedContent(
                    targetState = mode to picked,
                    transitionSpec = {
                        (fadeIn(ef) + scaleIn(sp, initialScale = 0.85f)) togetherWith (fadeOut(ef) + scaleOut(sp, targetScale = 0.9f))
                    },
                    label = "entryMode",
                ) { (md, pk) ->
                    when (md) {
                        0 -> Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            listOf(listOf(1, 2, 3), listOf(4, 5, 6)).forEach { rowNums ->
                                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    rowNums.forEach { n ->
                                        MorphTile(
                                            Modifier
                                                .weight(1f)
                                                .aspectRatio(1f),
                                            color = gradeColor(n.toDouble()),
                                            baseRadius = 24.dp,
                                            activeRadius = 60.dp,
                                            onClick = { if (tendencyOn) picked = n else commit(n.toDouble(), 0) },
                                        ) {
                                            Text("$n", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 44.sp)
                                        }
                                    }
                                }
                            }
                        }

                        1 -> Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            listOf(1 to "+", 0 to "", -1 to "-").forEach { (t, sign) ->
                                MorphTile(
                                    Modifier
                                        .weight(1f)
                                        .aspectRatio(1f),
                                    color = gradeColor(pk.toDouble()),
                                    baseRadius = 24.dp,
                                    activeRadius = 60.dp,
                                    onClick = { commit(pk.toDouble(), t) },
                                ) {
                                    Text("$pk$sign", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 44.sp)
                                }
                            }
                        }

                        else -> Column(
                            Modifier.fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Text(
                                fmt(slider.toDouble()),
                                fontSize = 56.sp,
                                fontWeight = FontWeight.Bold,
                                color = gradeColor(slider.toDouble()),
                            )
                            Slider(
                                value = slider,
                                onValueChange = { slider = (it * 10f).roundToInt() / 10f },
                                valueRange = 1f..6f,
                                steps = 49,
                            )
                            Button(onClick = { commit(slider.toDouble(), 0) }) { Text("Speichern") }
                        }
                    }
                }
            }

            AnimatedVisibility(visible = weightOn && r.kind != 2, enter = fadeIn(ef) + scaleIn(sp, initialScale = 0.9f), exit = fadeOut(ef) + scaleOut()) {
                ContainerCard("Gewichtung", Icons.Filled.Tune) {
                    Row(
                        Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center,
                    ) {
                        FilledTonalIconButton(onClick = { if (weight > 1) weight-- }) { Icon(Icons.Filled.Remove, "weniger") }
                        AnimatedContent(
                            targetState = weight,
                            transitionSpec = { (fadeIn(ef) + scaleIn(sp, initialScale = 0.6f)) togetherWith fadeOut(ef) },
                            label = "weight",
                            modifier = Modifier.width(96.dp),
                        ) { w ->
                            Text("${w}×", fontSize = 32.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                        }
                        FilledTonalIconButton(onClick = { if (weight < 5) weight++ }) { Icon(Icons.Filled.Add, "mehr") }
                    }
                }
            }

            ContainerCard("Optionen", Icons.Filled.Settings) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OptionToggle("+ / -", tendencyOn, Modifier.weight(1f)) {
                        tendencyOn = it; if (!it) picked = 0
                    }
                    OptionToggle("Komma", comma, Modifier.weight(1f)) { comma = it; picked = 0 }
                    if (r.kind != 2) OptionToggle("Gewicht", weightOn, Modifier.weight(1f)) { weightOn = it }
                }
                Text(
                    "Für mehr Optionen schau in den Einstellungen nach.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth(),
                )
            }

            if (existing != null || (r.kind == 2 && sub.finals.containsKey(r.sem))) {
                FilledTonalButton(
                    onClick = {
                        if (existing != null) vm.deleteGrade(existing.id) else vm.setFinal(r.subjectId, r.sem, null)
                        vm.pop()
                    },
                    modifier = Modifier.align(Alignment.CenterHorizontally),
                ) {
                    Icon(Icons.Filled.Delete, null)
                    Spacer(Modifier.width(8.dp))
                    Text(if (existing != null) "Note löschen" else "Festlegung entfernen")
                }
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable
private fun OptionToggle(label: String, checked: Boolean, modifier: Modifier, onChange: (Boolean) -> Unit) {
    MorphTile(
        modifier.height(56.dp),
        color = if (checked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceContainerHighest,
        selected = checked,
        baseRadius = 14.dp,
        activeRadius = 28.dp,
        onClick = { onChange(!checked) },
    ) {
        Text(
            label,
            color = if (checked) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
            fontWeight = FontWeight.Medium,
        )
    }
}
