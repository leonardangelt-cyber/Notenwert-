package com.notenwerk.app

import android.content.Context
import android.content.Intent
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import java.io.File
import java.time.LocalDate
import kotlin.math.roundToInt

private const val AUTHORITY = "com.notenwerk.app.files"

private fun shareFile(ctx: Context, file: File, mime: String) {
    val uri = FileProvider.getUriForFile(ctx, AUTHORITY, file)
    val i = Intent(Intent.ACTION_SEND).apply {
        type = mime
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    ctx.startActivity(Intent.createChooser(i, null))
}

private fun exportFile(ctx: Context, name: String): File {
    val dir = File(ctx.cacheDir, "exports")
    dir.mkdirs()
    return File(dir, name)
}

// ----------------------------------------------------------------- PDF

fun buildPdf(vm: AppVM, file: File) {
    val doc = PdfDocument()
    val pageW = 595
    val pageH = 842
    var pageNo = 1
    var page = doc.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, pageNo).create())
    var c = page.canvas
    var y = 56f

    fun paint(size: Float, bold: Boolean = false, color: Int = 0xFF1B1B1B.toInt()) = Paint().apply {
        textSize = size; isFakeBoldText = bold; isAntiAlias = true; this.color = color
    }
    val pTitle = paint(24f, true)
    val pH = paint(15f, true, 0xFF2F6A00.toInt())
    val pHead = paint(10.5f, true, 0xFF555555.toInt())
    val pBody = paint(11.5f)
    val pGray = paint(9.5f, false, 0xFF777777.toInt())
    val pLine = Paint().apply { color = 0xFFCCCCCC.toInt(); strokeWidth = 0.7f }

    fun newPage() {
        doc.finishPage(page)
        pageNo++
        page = doc.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, pageNo).create())
        c = page.canvas
        y = 56f
    }
    fun ensure(h: Float) {
        if (y + h > pageH - 50) newPage()
    }
    val x0 = 40f
    val x1 = 210f
    val x2 = 360f
    val x3 = 500f
    val places = vm.decimals

    fun row(a: String, b: String, cc: String, d: String, p: Paint = pBody) {
        ensure(22f)
        c.drawText(a.take(30), x0, y, p)
        c.drawText(b.take(24), x1, y, p)
        c.drawText(cc.take(24), x2, y, p)
        c.drawText(d, x3, y, p)
        y += 6f
        c.drawLine(x0, y, pageW - 40f, y, pLine)
        y += 16f
    }

    c.drawText(t("Notenübersicht"), x0, y, pTitle)
    y += 20f
    c.drawText(LocalDate.now().toString(), x0, y, pGray)
    y += 32f

    for (sem in 1..2) {
        val subs = vm.subjects.filter { sem in it.sems }
        if (subs.isEmpty()) continue
        ensure(70f)
        c.drawText(tf("{0}. Halbjahr", sem), x0, y, pH)
        y += 20f
        row(t("Fach"), t("schriftliche Noten"), t("mündliche Noten"), t("Durchschnitt"), pHead)
        for (s in subs) {
            val w = vm.gradesOf(s.id, sem, 0).joinToString(", ") { gradeLabel(it) }.ifEmpty { "–" }
            val o = vm.gradesOf(s.id, sem, 1).joinToString(", ") { gradeLabel(it) }.ifEmpty { "–" }
            row(s.name, w, o, fmtGrade(vm.avg(s, sem), places))
        }
        row(t("Gesamt"), "", "", fmtGrade(vm.semAvg(sem), places), paint(11.5f, true))
        y += 14f
    }

    val year = vm.subjects.filter { vm.yearAvg(it) != null }
    if (year.isNotEmpty()) {
        ensure(70f)
        c.drawText(t("Ende"), x0, y, pH)
        y += 20f
        row(t("Fach"), "1. HJ", "2. HJ", t("Durchschnitt"), pHead)
        for (s in year) {
            row(s.name, fmtGrade(vm.avg(s, 1), places), fmtGrade(vm.avg(s, 2), places), fmtGrade(vm.yearAvg(s), places))
        }
        row(t("Gesamt"), "", "", fmtGrade(vm.overallYear(), places), paint(11.5f, true))
    }
    doc.finishPage(page)
    file.outputStream().use { doc.writeTo(it) }
    doc.close()
}

// ----------------------------------------------------------------- Karten für die Einstellungen

@Composable
fun BackupCard(vm: AppVM) {
    val ctx = LocalContext.current
    var msg by remember { mutableStateOf<String?>(null) }
    var pending by remember { mutableStateOf<String?>(null) }

    val save = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            msg = try {
                ctx.contentResolver.openOutputStream(uri)?.use { it.write(vm.exportJson().toByteArray()) }
                t("Sicherung gespeichert.")
            } catch (_: Exception) {
                t("Das hat nicht geklappt.")
            }
        }
    }
    val open = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                pending = ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
            } catch (_: Exception) {
                msg = t("Das hat nicht geklappt.")
            }
        }
    }

    ContainerCard(t("Sicherung"), Icons.Filled.Download) {
        FilledTonalButton(onClick = withTap { save.launch("Notenwerk-Sicherung-${LocalDate.now()}.json") }, modifier = Modifier.fillMaxWidth()) {
            Text(t("Sicherung speichern"))
        }
        FilledTonalButton(
            onClick = withTap {
                try {
                    val f = exportFile(ctx, "Notenwerk-Sicherung.json")
                    f.writeText(vm.exportJson())
                    shareFile(ctx, f, "application/json")
                } catch (_: Exception) {
                    msg = t("Das hat nicht geklappt.")
                }
            },
            modifier = Modifier.fillMaxWidth(),
        ) { Text(t("Sicherung teilen")) }
        FilledTonalButton(onClick = withTap { open.launch(arrayOf("*/*")) }, modifier = Modifier.fillMaxWidth()) {
            Text(t("Sicherung laden"))
        }
        FilledTonalButton(
            onClick = withTap {
                try {
                    val f = exportFile(ctx, "Notenuebersicht.pdf")
                    buildPdf(vm, f)
                    shareFile(ctx, f, "application/pdf")
                } catch (_: Exception) {
                    msg = t("Das hat nicht geklappt.")
                }
            },
            modifier = Modifier.fillMaxWidth(),
        ) { Text(t("Notenübersicht als PDF")) }
        msg?.let { Text(it, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary) }
    }

    pending?.let { text ->
        AlertDialog(
            onDismissRequest = { pending = null },
            title = { Text(t("Sicherung laden?")) },
            text = { Text(t("Alle aktuellen Fächer und Noten werden durch die Sicherung ersetzt.")) },
            confirmButton = {
                TextButton(onClick = {
                    msg = if (vm.importJson(text)) t("Sicherung geladen.") else t("Diese Datei ist keine Notenwerk-Sicherung.")
                    pending = null
                }) { Text(t("Laden")) }
            },
            dismissButton = { TextButton(onClick = { pending = null }) { Text(t("Abbrechen")) } },
        )
    }
}

@Composable
fun SecurityCard(vm: AppVM) {
    if (Build.VERSION.SDK_INT < 30) return
    val ctx = LocalContext.current
    val tap = rememberTapHaptic()
    var err by remember { mutableStateOf(false) }
    ContainerCard(t("Sicherheit"), Icons.Filled.Lock) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(t("App-Sperre (Fingerabdruck oder Gerätesperre)"), Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
            Switch(checked = vm.appLock, onCheckedChange = { on ->
                tap()
                if (on && !canAuth(ctx)) {
                    err = true
                } else {
                    err = false
                    vm.updateAppLock(on)
                }
            })
        }
        Text(
            t("Nach 30 Sekunden im Hintergrund fragt die App erneut. In der App-Übersicht wird der Inhalt ausgeblendet."),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        if (err) Text(t("Richte zuerst eine Bildschirmsperre oder einen Fingerabdruck in den Handy-Einstellungen ein."), color = MaterialTheme.colorScheme.error)
    }
}
