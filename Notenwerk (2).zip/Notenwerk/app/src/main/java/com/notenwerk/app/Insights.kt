@file:OptIn(ExperimentalLayoutApi::class)

package com.notenwerk.app

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.roundToInt

// ----------------------------------------------------------------- Warnung

@Composable
fun WarningBanner(text: String) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(MaterialTheme.colorScheme.errorContainer)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Filled.Warning, null, tint = MaterialTheme.colorScheme.onErrorContainer)
        Spacer(Modifier.width(12.dp))
        Text(text, color = MaterialTheme.colorScheme.onErrorContainer, style = MaterialTheme.typography.bodyLarge)
    }
}

// ----------------------------------------------------------------- Diagramm




// ----------------------------------------------------------------- Planer

@Composable
fun PlannerCard(vm: AppVM, s: Subject, sem: Int) {
    val avg = vm.avg(s, sem)
    val pts = vm.pointMode
    val places = LocalDecimals.current
    var mode by rememberSaveable { mutableIntStateOf(0) }
    var kind by rememberSaveable { mutableIntStateOf(1) }
    var weight by rememberSaveable { mutableIntStateOf(1) }
    var tgt by rememberSaveable { mutableFloatStateOf(if (s.target > 0) s.target.toFloat() else 2.0f) }
    var sim by rememberSaveable { mutableFloatStateOf(2.0f) }

    fun toSlider(note: Float): Float = if (pts) pointsFromNote(note.toDouble()).toFloat() else note
    fun fromSlider(v: Float): Float = if (pts) noteEq(v.roundToInt().toDouble()).toFloat() else (v * 10f).roundToInt() / 10f
    val lo = if (pts) noteEq(15.0) else 1.0
    val hi = if (pts) noteEq(0.0) else 6.0

    ContainerCard(t("Planer"), Icons.Filled.TrendingUp) {
        if (s.finals.containsKey(sem)) {
            Text(t("Für dieses Halbjahr ist eine Note festgelegt."), color = MaterialTheme.colorScheme.onSurfaceVariant)
            return@ContainerCard
        }
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = mode == 0, onClick = withTap { mode = 0 }, label = { Text(t("Zielnote")) })
            FilterChip(selected = mode == 1, onClick = withTap { mode = 1 }, label = { Text(t("Was wäre wenn")) })
        }
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = kind == 0, onClick = withTap { kind = 0 }, label = { Text(t("schriftliche Noten")) })
            FilterChip(selected = kind == 1, onClick = withTap { kind = 1 }, label = { Text(t("mündliche Noten")) })
        }
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            (1..3).forEach { w ->
                FilterChip(selected = weight == w, onClick = withTap { weight = w }, label = { Text("${w}×") })
            }
        }

        if (mode == 0) {
            Text(
                tf("Zielnote: {0}", fmtGrade(tgt.toDouble(), if (pts) 0 else 1)),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
            )
            Slider(
                value = toSlider(tgt),
                onValueChange = { tgt = fromSlider(it) },
                onValueChangeFinished = { vm.setTarget(s.id, tgt.toDouble()) },
                valueRange = if (pts) 0f..15f else 1f..6f,
                steps = if (pts) 14 else 49,
            )
            val need = vm.neededGrade(s, sem, kind, weight, tgt.toDouble())
            val msg = when {
                need == null -> t("Diese Gruppe zählt 0 %. Ändere die Gewichtung unter „Gruppen“.")
                need < lo - 1e-6 -> t("Ziel nicht mehr erreichbar.")
                need >= hi - 1e-6 -> t("Ziel ist auf jeden Fall erreicht.")
                pts -> tf("Die nächste Note braucht mindestens {0} Punkte.", ceil(17.0 - 3.0 * need - 1e-9).toInt().coerceIn(0, 15))
                else -> tf("Die nächste Note darf höchstens eine {0} sein (genau: {1}).", floor(need + 1e-9).toInt().coerceIn(1, 6), fmt(need, 2))
            }
            Text(msg, style = MaterialTheme.typography.bodyLarge)
        } else {
            Text(
                tf("Angenommene Note: {0}", fmtGrade(sim.toDouble(), if (pts) 0 else 1)),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
            )
            Slider(
                value = toSlider(sim),
                onValueChange = { sim = fromSlider(it) },
                valueRange = if (pts) 0f..15f else 1f..6f,
                steps = if (pts) 14 else 49,
            )
            val newAvg = vm.avgWith(s, sem, kind, sim.toDouble(), weight)
            Row(verticalAlignment = Alignment.CenterVertically) {
                GradeBubble(newAvg, 64.dp)
                Spacer(Modifier.width(16.dp))
                Text(
                    tf("Schnitt: {0} → {1}", fmtGrade(avg, places), fmtGrade(newAvg, places)),
                    style = MaterialTheme.typography.titleMedium,
                )
            }
            Text(t("Die Note wird nur durchgerechnet und nicht gespeichert."), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        avg?.let {
            val z = if (pts) pointsFromNote(it).roundToInt() else it.roundToInt().coerceIn(1, 6)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Flag, null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(8.dp))
                Text(tf("Voraussichtliche Zeugnisnote: {0}", z), style = MaterialTheme.typography.bodyLarge)
            }
        }
    }
}

// ----------------------------------------------------------------- Alle Noten

