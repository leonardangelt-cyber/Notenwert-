package com.notenwerk.app

import android.app.Application
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import kotlin.math.roundToInt

/** Notensystem: false = Noten 1–6 (mit +/-), true = Punkte 0–15. */
object GradeMode {
    var points by mutableStateOf(false)
}

/** Punkte (0–15) -> Note und Tendenz. 15 = 1+, 14 = 1, 13 = 1-, ... 1 = 5-, 0 = 6. */
fun pointsToGrade(p: Int): Pair<Double, Int> {
    if (p <= 0) return 6.0 to 0
    val k = 15 - p.coerceAtMost(15)
    return (k / 3 + 1).toDouble() to (1 - k % 3)
}

fun pointsOf(g: Grade): Int {
    val v = g.value
    if (v % 1.0 == 0.0) {
        val n = v.toInt()
        if (n >= 6) return 0
        if (n < 1) return 15
        return (15 - ((n - 1) * 3 + (1 - g.tendency))).coerceIn(0, 15)
    }
    return (17 - 3 * v).roundToInt().coerceIn(0, 15)
}

fun noteEq(p: Double): Double = (17.0 - p) / 3.0

fun pointsFromNote(n: Double): Double = (17.0 - 3.0 * n).coerceIn(0.0, 15.0)

sealed interface Route {
    val depth: Int

    data object Home : Route {
        override val depth = 0
    }

    data class AddSubject(val sem: Int) : Route {
        override val depth = 1
    }

    data class SubjectDetail(val id: String, val sem: Int) : Route {
        override val depth = 1
    }

    /** kind: 0 = schriftlich, 1 = mündlich, 2 = Note festlegen */
    data class Entry(val subjectId: String, val sem: Int, val kind: Int, val gradeId: String?) : Route {
        override val depth = 2
    }
}

data class Grade(
    val id: String,
    val subjectId: String,
    val sem: Int,
    val kind: Int,
    val value: Double,
    val tendency: Int,
    val weight: Int,
    /** Tag als Epoch-Day (0 = unbekannt) */
    val date: Long = 0L,
    val note: String = "",
)

data class Subject(
    val id: String,
    val name: String,
    val sems: Set<Int>,
    val writtenPct: Int = 40,
    val examPct: Int = 0,
    val finals: Map<Int, Double> = emptyMap(),
    val iconKey: String? = null,
    /** Zielnote (Notenskala), 0 = keine */
    val target: Double = 0.0,
)

fun badgeText(avg: Double, meanTendency: Double = 0.0): String {
    if (GradeMode.points) return pointsFromNote(avg).roundToInt().toString()
    val r = avg.roundToInt().coerceIn(1, 6)
    val f = avg - r
    val t = when {
        f <= -0.17 -> 1
        f >= 0.17 -> -1
        else -> meanTendency.roundToInt()
    }
    return r.toString() + when (t) {
        1 -> "+"
        -1 -> "-"
        else -> ""
    }
}

class AppVM(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("notenwerk", Context.MODE_PRIVATE)

    val subjects = mutableStateListOf<Subject>()
    val grades = mutableStateListOf<Grade>()
    val stack = mutableStateListOf<Route>()

    /** Zuletzt geöffnetes Fach: Die Liste zentriert es beim Zurückkehren. */
    var lastOpened: String? = null

    var tab by mutableIntStateOf(currentHalf(prefs.getString("bundesland", "") ?: "") - 1)

    /** 0 = System, 1 = Hell, 2 = Dunkel */
    var themeMode by mutableIntStateOf(prefs.getInt("theme", 0))
        private set
    var dynamicColor by mutableStateOf(prefs.getBoolean("dynamic", true))
        private set
    var accent by mutableIntStateOf(prefs.getInt("accent", 0))
        private set
    var tendencyDefault by mutableStateOf(prefs.getBoolean("tendencyDefault", true))
        private set
    var tendencyCounts by mutableStateOf(prefs.getBoolean("tendencyCounts", false))
        private set
    var decimals by mutableIntStateOf(prefs.getInt("decimals", 1))
        private set
    var bundesland by mutableStateOf(prefs.getString("bundesland", "") ?: "")
        private set
    var pointMode by mutableStateOf(prefs.getBoolean("points", false))
        private set
    var appLock by mutableStateOf(prefs.getBoolean("lock", false))
        private set
    var onboarded by mutableStateOf(prefs.getBoolean("onboarded", false))
        private set

    init {
        load()
        GradeMode.points = pointMode
        val saved = prefs.getString("lang", "de") ?: "de"
        if (!I18n.apply(app, saved)) I18n.apply(app, "de")
    }

    val current: Route get() = stack.lastOrNull() ?: Route.Home

    fun push(r: Route) {
        stack.add(r)
    }

    fun pop() {
        if (stack.isNotEmpty()) stack.removeAt(stack.lastIndex)
    }

    // ---------- Einstellungen ----------
    fun updateThemeMode(v: Int) {
        themeMode = v; prefs.edit().putInt("theme", v).apply()
    }

    fun updateDecimals(v: Int) {
        decimals = v.coerceIn(0, 3); prefs.edit().putInt("decimals", decimals).apply()
    }

    fun updateBundesland(code: String) {
        bundesland = code; prefs.edit().putString("bundesland", code).apply()
        autoHalf()
    }

    /** Springt automatisch ins aktuelle Halbjahr (nur wenn gerade ein Halbjahr-Tab offen ist). */
    fun autoHalf() {
        if (tab <= 1) tab = currentHalf(bundesland) - 1
    }

    fun updatePointMode(v: Boolean) {
        pointMode = v; GradeMode.points = v; prefs.edit().putBoolean("points", v).apply()
    }

    fun finishOnboarding() {
        onboarded = true; prefs.edit().putBoolean("onboarded", true).apply()
    }

    /** Wendet eine installierte Sprache an und merkt sie sich. */
    fun updateLanguage(code: String): Boolean {
        val ok = I18n.apply(getApplication<Application>(), code)
        if (ok) prefs.edit().putString("lang", code).apply()
        return ok
    }

    fun updateAppLock(v: Boolean) {
        appLock = v; prefs.edit().putBoolean("lock", v).apply()
    }

    fun updateAccent(i: Int) {
        accent = i; prefs.edit().putInt("accent", i).apply()
    }

    fun setDynamic(v: Boolean) {
        dynamicColor = v; prefs.edit().putBoolean("dynamic", v).apply()
    }

    fun updateTendencyDefault(v: Boolean) {
        tendencyDefault = v; prefs.edit().putBoolean("tendencyDefault", v).apply()
    }

    fun updateTendencyCounts(v: Boolean) {
        tendencyCounts = v; prefs.edit().putBoolean("tendencyCounts", v).apply()
    }

    // ---------- Berechnung ----------
    private fun eff(g: Grade): Double =
        if (GradeMode.points) noteEq(pointsOf(g).toDouble())
        else if (tendencyCounts) g.value - g.tendency * 0.33 else g.value

    fun effective(g: Grade): Double = eff(g).coerceIn(1.0, 6.0)

    private fun weighted(list: List<Grade>): Double? {
        if (list.isEmpty()) return null
        val w = list.sumOf { it.weight }.toDouble()
        return list.sumOf { eff(it) * it.weight } / w
    }

    fun gradesOf(subjectId: String, sem: Int, kind: Int): List<Grade> =
        grades.filter { it.subjectId == subjectId && it.sem == sem && it.kind == kind }

    fun avg(s: Subject, sem: Int): Double? {
        s.finals[sem]?.let { return it }
        return avgCalc(s, grades.filter { it.subjectId == s.id && it.sem == sem })
    }

    /** Durchschnitt aus einer beliebigen Notenliste (für Verlauf und „Was wäre wenn“). */
    private fun avgCalc(s: Subject, list: List<Grade>): Double? {
        // Gruppen: Klassenarbeiten (3), schriftlich (0), mündlich (1)
        val oral = (100 - s.writtenPct - s.examPct).coerceAtLeast(0)
        val parts = listOf(3 to s.examPct, 0 to s.writtenPct, 1 to oral)
        var num = 0.0
        var den = 0.0
        var plainSum = 0.0
        var plainN = 0
        for ((kind, pct) in parts) {
            val a = weighted(list.filter { it.kind == kind }) ?: continue
            plainSum += a
            plainN++
            if (pct > 0) {
                num += a * pct
                den += pct
            }
        }
        val res = when {
            den > 0 -> num / den
            plainN > 0 -> plainSum / plainN
            else -> null
        }
        return if (GradeMode.points) res?.coerceIn(noteEq(15.0), noteEq(0.0)) else res?.coerceIn(1.0, 6.0)
    }

    /** Durchschnitt, wenn eine weitere Note (Notenskala bzw. Punkte-Äquivalent) dazukäme. */
    fun avgWith(s: Subject, sem: Int, kind: Int, value: Double, weight: Int): Double? {
        val extra = Grade("sim", s.id, sem, kind, value, 0, weight)
        return avgCalc(s, grades.filter { it.subjectId == s.id && it.sem == sem } + extra)
    }

    /**
     * Schlechteste Note (Notenskala), die in der nächsten Note der Gruppe noch reicht, um die Zielnote zu halten.
     * null, wenn die Gruppe nicht zählt.
     */
    fun neededGrade(s: Subject, sem: Int, kind: Int, weight: Int, target: Double): Double? {
        val oral = (100 - s.writtenPct - s.examPct).coerceAtLeast(0)
        val pctOf = mapOf(3 to s.examPct, 0 to s.writtenPct, 1 to oral)
        val pct = pctOf[kind] ?: 0
        if (pct <= 0) return null
        var a = 0.0
        var d = 0.0
        for ((k, p) in pctOf) {
            if (k == kind || p <= 0) continue
            val g = weighted(gradesOf(s.id, sem, k)) ?: continue
            a += g * p
            d += p
        }
        val own = gradesOf(s.id, sem, kind)
        val sumOwn = own.sumOf { eff(it) * it.weight }
        val wOwn = own.sumOf { it.weight }.toDouble()
        val gk = (target * (d + pct) - a) / pct
        return (gk * (wOwn + weight) - sumOwn) / weight
    }

    private fun sortedGrades(list: List<Grade>): List<Grade> =
        list.withIndex().sortedWith(compareBy({ it.value.date }, { it.index })).map { it.value }

    /** Verlauf eines Fachs: je Note (Wert, laufender Schnitt), nach Datum sortiert. */
    fun history(s: Subject, sem: Int): List<Pair<Double, Double>> {
        val list = sortedGrades(grades.filter { it.subjectId == s.id && it.sem == sem })
        return list.indices.mapNotNull { i ->
            avgCalc(s, list.take(i + 1))?.let { eff(list[i]) to it }
        }
    }

    /** Verlauf des Gesamtschnitts eines Halbjahrs. */
    fun overallHistory(sem: Int): List<Double> {
        val subs = subjects.filter { sem in it.sems }
        val ids = subs.map { it.id }.toSet()
        val all = sortedGrades(grades.filter { it.sem == sem && it.subjectId in ids })
        val out = ArrayList<Double>()
        for (i in all.indices) {
            val part = all.take(i + 1)
            val avgs = subs.mapNotNull { sub ->
                if (sub.finals.containsKey(sem)) sub.finals[sem]
                else avgCalc(sub, part.filter { it.subjectId == sub.id })
            }
            if (avgs.isNotEmpty()) out.add(avgs.average())
        }
        return out
    }

    /** Hinweis, wenn der Schnitt gefährlich ist oder zuletzt gefallen ist. */
    fun warning(s: Subject, sem: Int): String? {
        val a = avg(s, sem) ?: return null
        if (a >= 4.5) return "Achtung: Der Schnitt liegt bei 5 oder schlechter."
        val h = history(s, sem)
        if (h.size >= 4 && h.last().second - h[h.size - 4].second >= 0.5) return "Der Schnitt ist zuletzt deutlich gefallen."
        return null
    }

    fun setTarget(id: String, v: Double) {
        val i = subjects.indexOfFirst { it.id == id }
        if (i < 0) return
        subjects[i] = subjects[i].copy(target = v)
        save()
    }

    fun badge(s: Subject, sem: Int): String? {
        val a = avg(s, sem) ?: return null
        val own = if (s.finals.containsKey(sem)) emptyList()
        else grades.filter { it.subjectId == s.id && it.sem == sem }
        val mean = if (own.isEmpty()) 0.0 else own.map { it.tendency }.average()
        return badgeText(a, mean)
    }

    fun semAvg(sem: Int): Double? {
        val list = subjects.filter { sem in it.sems }.mapNotNull { avg(it, sem) }
        return if (list.isEmpty()) null else list.average()
    }

    fun yearAvg(s: Subject): Double? {
        val list = s.sems.sorted().mapNotNull { avg(s, it) }
        return if (list.isEmpty()) null else list.average()
    }

    fun overallYear(): Double? {
        val list = subjects.mapNotNull { yearAvg(it) }
        return if (list.isEmpty()) null else list.average()
    }

    // ---------- Änderungen ----------
    fun addSubject(name: String, sems: Set<Int>, iconKey: String? = null) {
        val n = name.trim()
        if (n.isEmpty() || sems.isEmpty()) return
        val idx = subjects.indexOfFirst { it.name.equals(n, ignoreCase = true) }
        if (idx >= 0) {
            val old = subjects[idx]
            subjects[idx] = old.copy(sems = old.sems + sems, iconKey = iconKey ?: old.iconKey)
        } else {
            subjects.add(Subject(UUID.randomUUID().toString(), n, sems, 40, 0, emptyMap(), iconKey))
        }
        save()
    }

    fun setIcon(id: String, key: String?) {
        val i = subjects.indexOfFirst { it.id == id }
        if (i < 0) return
        subjects[i] = subjects[i].copy(iconKey = key)
        save()
    }

    fun renameSubject(id: String, name: String) {
        val n = name.trim()
        val i = subjects.indexOfFirst { it.id == id }
        if (i < 0 || n.isEmpty()) return
        subjects[i] = subjects[i].copy(name = n)
        save()
    }

    fun setGroups(id: String, written: Int, exam: Int) {
        val i = subjects.indexOfFirst { it.id == id }
        if (i < 0) return
        val e = exam.coerceIn(0, 100)
        val w = written.coerceIn(0, 100 - e)
        subjects[i] = subjects[i].copy(writtenPct = w, examPct = e)
        save()
    }

    fun deleteSubject(id: String) {
        subjects.removeAll { it.id == id }
        grades.removeAll { it.subjectId == id }
        save()
    }

    fun saveGrade(g: Grade) {
        val i = grades.indexOfFirst { it.id == g.id }
        if (i >= 0) grades[i] = g else grades.add(g)
        save()
    }

    fun deleteGrade(id: String) {
        grades.removeAll { it.id == id }
        save()
    }

    fun setFinal(subjectId: String, sem: Int, value: Double?) {
        val i = subjects.indexOfFirst { it.id == subjectId }
        if (i < 0) return
        val s = subjects[i]
        subjects[i] = s.copy(
            finals = if (value == null) s.finals - sem else s.finals + (sem to value)
        )
        save()
    }

    fun resetAll() {
        subjects.clear()
        grades.clear()
        stack.clear()
        save()
    }

    // ---------- Speichern / Laden ----------
    private fun subjectsJson(): JSONArray {
        val sa = JSONArray()
        for (s in subjects) {
            val fin = JSONObject()
            for ((k, v) in s.finals) fin.put(k.toString(), v)
            sa.put(
                JSONObject()
                    .put("id", s.id)
                    .put("name", s.name)
                    .put("sems", JSONArray(s.sems.toList()))
                    .put("w", s.writtenPct)
                    .put("x", s.examPct)
                    .put("finals", fin)
                    .put("ic", s.iconKey ?: "")
                    .put("tg", s.target)
            )
        }
        return sa
    }

    private fun gradesJson(): JSONArray {
        val ga = JSONArray()
        for (g in grades) {
            ga.put(
                JSONObject()
                    .put("id", g.id)
                    .put("s", g.subjectId)
                    .put("sem", g.sem)
                    .put("k", g.kind)
                    .put("v", g.value)
                    .put("t", g.tendency)
                    .put("w", g.weight)
                    .put("d", g.date)
                    .put("n", g.note)
            )
        }
        return ga
    }

    private fun save() {
        prefs.edit().putString("subjects", subjectsJson().toString()).putString("grades", gradesJson().toString()).apply()
    }

    /** Komplette Sicherung (Fächer, Noten, Einstellungen) als JSON-Text. */
    fun exportJson(): String {
        val set = JSONObject()
            .put("theme", themeMode).put("dynamic", dynamicColor).put("accent", accent)
            .put("tendencyDefault", tendencyDefault).put("tendencyCounts", tendencyCounts)
            .put("decimals", decimals).put("points", pointMode).put("bundesland", bundesland)
            .put("lang", I18n.code)
        return JSONObject()
            .put("app", "Notenwerk").put("version", 1)
            .put("subjects", subjectsJson()).put("grades", gradesJson()).put("settings", set)
            .toString(2)
    }

    /** Ersetzt alle Daten durch den Inhalt einer Sicherung. Gibt false zurück, wenn die Datei nicht passt. */
    fun importJson(text: String): Boolean {
        return try {
            val o = JSONObject(text)
            if (o.optString("app") != "Notenwerk") return false
            val sa = o.getJSONArray("subjects")
            val ga = o.getJSONArray("grades")
            prefs.edit().putString("subjects", sa.toString()).putString("grades", ga.toString()).apply()
            subjects.clear(); grades.clear(); stack.clear()
            load()
            o.optJSONObject("settings")?.let { st ->
                updateThemeMode(st.optInt("theme", themeMode))
                setDynamic(st.optBoolean("dynamic", dynamicColor))
                updateAccent(st.optInt("accent", accent))
                updateTendencyDefault(st.optBoolean("tendencyDefault", tendencyDefault))
                updateTendencyCounts(st.optBoolean("tendencyCounts", tendencyCounts))
                updateDecimals(st.optInt("decimals", decimals))
                updatePointMode(st.optBoolean("points", pointMode))
                val bl = st.optString("bundesland", bundesland)
                if (bl.isNotEmpty()) updateBundesland(bl)
                val lg = st.optString("lang", I18n.code)
                if (languages.any { it.code == lg }) updateLanguage(lg)
            }
            true
        } catch (_: Exception) {
            false
        }
    }

    private fun load() {
        try {
            val sa = JSONArray(prefs.getString("subjects", "[]"))
            for (i in 0 until sa.length()) {
                val o = sa.getJSONObject(i)
                val semsArr = o.getJSONArray("sems")
                val sems = (0 until semsArr.length()).map { semsArr.getInt(it) }.toSet()
                val finObj = o.optJSONObject("finals") ?: JSONObject()
                val fin = HashMap<Int, Double>()
                for (k in finObj.keys()) fin[k.toInt()] = finObj.getDouble(k)
                subjects.add(Subject(o.getString("id"), o.getString("name"), sems, o.optInt("w", 40), o.optInt("x", 0), fin, o.optString("ic", "").ifEmpty { null }, o.optDouble("tg", 0.0)))
            }
            val ga = JSONArray(prefs.getString("grades", "[]"))
            for (i in 0 until ga.length()) {
                val o = ga.getJSONObject(i)
                grades.add(
                    Grade(
                        o.getString("id"), o.getString("s"), o.getInt("sem"), o.getInt("k"),
                        o.getDouble("v"), o.optInt("t", 0), o.optInt("w", 1),
                        o.optLong("d", 0L), o.optString("n", "")
                    )
                )
            }
        } catch (_: Exception) {
            subjects.clear(); grades.clear()
        }
    }
}
