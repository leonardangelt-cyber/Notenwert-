package com.notenwerk.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONObject
import java.util.Locale

class Lang(val code: String, val name: String)

val languages = listOf(
    Lang("de", "Deutsch"),
    Lang("en", "English"),
    Lang("fr", "Français"),
    Lang("es", "Español"),
    Lang("it", "Italiano"),
    Lang("tr", "Türkçe"),
    Lang("pl", "Polski"),
)

object I18n {
    /** Deutscher Text -> Übersetzung. Leer = Deutsch. */
    var map by mutableStateOf<Map<String, String>>(emptyMap())
    var code by mutableStateOf("de")

    val locale: Locale get() = Locale.forLanguageTag(code)

    /** Lädt die Sprache aus den mitgelieferten Dateien (assets/lang). */
    fun apply(ctx: Context, c: String): Boolean {
        if (c == "de") {
            map = emptyMap(); code = "de"; return true
        }
        return try {
            val text = ctx.assets.open("lang/lang-$c.json").bufferedReader().use { it.readText() }
            val o = JSONObject(text)
            val m = HashMap<String, String>(o.length())
            for (k in o.keys()) m[k] = o.getString(k)
            map = m
            code = c
            true
        } catch (_: Exception) {
            false
        }
    }
}

/** Übersetzt einen deutschen Text. Fehlt die Übersetzung, bleibt der deutsche Text stehen. */
fun t(s: String): String = I18n.map[s] ?: s

/** Wie t(), mit Platzhaltern {0}, {1} … */
fun tf(s: String, vararg a: Any): String {
    var r = t(s)
    a.forEachIndexed { i, v -> r = r.replace("{$i}", v.toString()) }
    return r
}
