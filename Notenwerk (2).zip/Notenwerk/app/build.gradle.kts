plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.notenwerk.app"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.notenwerk.app"
        minSdk = 26
        targetSdk = 36
        // Jeder GitHub-Lauf zählt hoch, dadurch erkennt Android die APK als Update.
        val build = System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 1
        versionCode = build
        versionName = "1.$build"
    }

    // Fester Schlüssel: nur mit immer demselben Schlüssel lässt sich die App überinstallieren.
    signingConfigs {
        create("notenwerk") {
            storeFile = file("notenwerk.jks")
            storePassword = "notenwerk123"
            keyAlias = "notenwerk"
            keyPassword = "notenwerk123"
        }
    }

    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("notenwerk")
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            signingConfig = signingConfigs.getByName("notenwerk")
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2025.09.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.animation:animation")
    // Material 3 Expressive (MaterialExpressiveTheme, MotionScheme, MaterialShapes)
    implementation("androidx.compose.material3:material3:1.4.0-alpha15")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.graphics:graphics-shapes:1.0.1")
    implementation("androidx.activity:activity-compose:1.10.1")
    implementation("androidx.core:core-ktx:1.15.0")
}
