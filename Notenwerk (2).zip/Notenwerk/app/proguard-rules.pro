-keepattributes *Annotation*
-keep class com.notenwerk.app.AppVM { *; }
-dontwarn javax.annotation.**

