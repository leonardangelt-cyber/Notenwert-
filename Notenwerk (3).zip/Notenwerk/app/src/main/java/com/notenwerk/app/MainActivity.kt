@file:OptIn(ExperimentalMaterial3ExpressiveApi::class)

package com.notenwerk.app

import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.IntOffset
import androidx.lifecycle.ViewModelProvider

class MainActivity : ComponentActivity() {
    /** Bittet das Display um die höchste Bildwiederholrate (z. B. 120 Hz) bei gleicher Auflösung. */
    private fun requestHighRefreshRate() {
        try {
            @Suppress("DEPRECATION")
            val d = if (Build.VERSION.SDK_INT >= 30) display else windowManager.defaultDisplay
            d ?: return
            val cur = d.mode
            val best = d.supportedModes
                .filter { it.physicalWidth == cur.physicalWidth && it.physicalHeight == cur.physicalHeight }
                .maxByOrNull { it.refreshRate } ?: return
            val lp = window.attributes
            lp.preferredDisplayModeId = best.modeId
            lp.preferredRefreshRate = best.refreshRate
            window.attributes = lp
        } catch (_: Throwable) {
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        requestHighRefreshRate()
        val vm = ViewModelProvider(this)[AppVM::class.java]
        setContent { App(vm) }
    }
}

@Composable
fun App(vm: AppVM) {
    val sysDark = isSystemInDarkTheme()
    val dark = when (vm.themeMode) {
        1 -> false
        2 -> true
        else -> sysDark
    }
    val activity = LocalContext.current as ComponentActivity
    LaunchedEffect(dark) {
        val style = SystemBarStyle.auto(
            android.graphics.Color.TRANSPARENT,
            android.graphics.Color.TRANSPARENT,
        ) { dark }
        activity.enableEdgeToEdge(statusBarStyle = style, navigationBarStyle = style)
    }
    NotenTheme(dark = dark, dynamic = vm.dynamicColor) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            CompositionLocalProvider(LocalDecimals provides vm.decimals) { Root(vm) }
        }
    }
}

@Composable
fun Root(vm: AppVM) {
    BackHandler(enabled = vm.stack.isNotEmpty()) { vm.pop() }

    val motion = MaterialTheme.motionScheme
    val spatial = motion.defaultSpatialSpec<IntOffset>()
    val effects = motion.defaultEffectsSpec<Float>()

    AnimatedContent(
        targetState = vm.current,
        transitionSpec = {
            val forward = targetState.depth >= initialState.depth
            val t = if (forward) {
                (slideInHorizontally(spatial) { it / 3 } + fadeIn(effects)) togetherWith
                        (slideOutHorizontally(spatial) { -it / 5 } + fadeOut(effects))
            } else {
                (slideInHorizontally(spatial) { -it / 5 } + fadeIn(effects)) togetherWith
                        (slideOutHorizontally(spatial) { it / 3 } + fadeOut(effects))
            }
            t.targetContentZIndex = if (forward) 1f else -1f
            t
        },
        label = "nav",
    ) { route ->
        when (route) {
            is Route.Home -> HomeShell(vm)
            is Route.AddSubject -> AddSubjectScreen(vm)
            is Route.SubjectDetail -> SubjectScreen(vm, route.id, route.sem)
            is Route.Entry -> EntryScreen(vm, route)
        }
    }
}
