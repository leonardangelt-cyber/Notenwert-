@file:OptIn(ExperimentalMaterial3ExpressiveApi::class)

package com.notenwerk.app

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Accessibility
import androidx.compose.material.icons.filled.Apartment
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.ChildCare
import androidx.compose.material.icons.filled.ChildFriendly
import androidx.compose.material.icons.filled.Class
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Comment
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Domain
import androidx.compose.material.icons.filled.Eco
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.EmojiObjects
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Forum
import androidx.compose.material.icons.filled.GTranslate
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Kitchen
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LibraryBooks
import androidx.compose.material.icons.filled.LocalActivity
import androidx.compose.material.icons.filled.LocalFlorist
import androidx.compose.material.icons.filled.LocalHospital
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.NightsStay
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.PersonPin
import androidx.compose.material.icons.filled.Poll
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.QuestionAnswer
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.SentimentSatisfied
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.SortByAlpha
import androidx.compose.material.icons.filled.Spa
import androidx.compose.material.icons.filled.Spellcheck
import androidx.compose.material.icons.filled.SportsSoccer
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.SupervisorAccount
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material.icons.filled.Textsms
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialShapes
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.toShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.Dp

/** Jedem Fach sein eigenes Symbol. */
private val subjectIcons: Map<String, ImageVector> by lazy {
    mapOf(
        "architektur" to Icons.Filled.Apartment,
        "astronomie" to Icons.Filled.NightsStay,
        "bwl" to Icons.Filled.BarChart,
        "bwr" to Icons.Filled.Receipt,
        "biologie" to Icons.Filled.Eco,
        "chemie" to Icons.Filled.Science,
        "chinesisch" to Icons.Filled.Translate,
        "chor" to Icons.Filled.Mic,
        "darstellendes spiel" to Icons.Filled.Face,
        "deutsch" to Icons.Filled.Edit,
        "englisch" to Icons.Filled.Forum,
        "erdkunde" to Icons.Filled.Public,
        "ernährung" to Icons.Filled.Restaurant,
        "erziehung" to Icons.Filled.ChildCare,
        "ethik" to Icons.Filled.Accessibility,
        "evang. religion" to Icons.Filled.Favorite,
        "französisch" to Icons.Filled.Language,
        "grw" to Icons.Filled.Domain,
        "gemeinschaftskunde" to Icons.Filled.Groups,
        "geographie" to Icons.Filled.Map,
        "geschichte" to Icons.Filled.AccountBalance,
        "gesellschaftslehre" to Icons.Filled.SupervisorAccount,
        "gesundheit" to Icons.Filled.LocalHospital,
        "griechisch" to Icons.Filled.SortByAlpha,
        "hauswirtschaft" to Icons.Filled.Home,
        "informatik" to Icons.Filled.Code,
        "italienisch" to Icons.Filled.Chat,
        "japanisch" to Icons.Filled.Subtitles,
        "kath. religion" to Icons.Filled.Spa,
        "kochen" to Icons.Filled.Kitchen,
        "kunst" to Icons.Filled.Palette,
        "latein" to Icons.Filled.Spellcheck,
        "literatur" to Icons.Filled.MenuBook,
        "mathematik" to Icons.Filled.Calculate,
        "medien" to Icons.Filled.Movie,
        "musik" to Icons.Filled.MusicNote,
        "nwt" to Icons.Filled.Memory,
        "naturwissenschaften" to Icons.Filled.LocalFlorist,
        "niederländisch" to Icons.Filled.ChatBubble,
        "p-seminar" to Icons.Filled.EmojiObjects,
        "philosophie" to Icons.Filled.QuestionAnswer,
        "physik" to Icons.Filled.Bolt,
        "politik" to Icons.Filled.Flag,
        "politik und gesellschaft" to Icons.Filled.Poll,
        "politik und wirtschaft" to Icons.Filled.TrendingUp,
        "psychologie" to Icons.Filled.SentimentSatisfied,
        "pädagogik" to Icons.Filled.ChildFriendly,
        "rechnungswesen" to Icons.Filled.AccountBalanceWallet,
        "recht" to Icons.Filled.Gavel,
        "rechtskunde" to Icons.Filled.Description,
        "religion" to Icons.Filled.Star,
        "rhetorik" to Icons.Filled.RecordVoiceOver,
        "russisch" to Icons.Filled.Textsms,
        "seminarfach" to Icons.Filled.School,
        "seminarkurs" to Icons.Filled.Class,
        "sozialkunde" to Icons.Filled.People,
        "sozialwissenschaften" to Icons.Filled.Group,
        "soziologie" to Icons.Filled.PersonPin,
        "spanisch" to Icons.Filled.GTranslate,
        "sport" to Icons.Filled.FitnessCenter,
        "technik" to Icons.Filled.Settings,
        "theater" to Icons.Filled.LocalActivity,
        "türkisch" to Icons.Filled.Comment,
        "vwl" to Icons.Filled.ShowChart,
        "w-seminar" to Icons.Filled.LibraryBooks,
        "werken" to Icons.Filled.Build,
        "werte und normen" to Icons.Filled.Security,
        "wirtschaft" to Icons.Filled.AttachMoney,
        "wirtschaft und recht" to Icons.Filled.Gavel,
    )
}

fun iconFor(name: String): ImageVector {
    val n = name.trim().lowercase()
    subjectIcons[n]?.let { return it }
    return when {
        "bio" in n -> Icons.Filled.Eco
        "mathe" in n -> Icons.Filled.Calculate
        "sport" in n -> Icons.Filled.SportsSoccer
        "musik" in n -> Icons.Filled.MusicNote
        "kunst" in n -> Icons.Filled.Brush
        "physik" in n -> Icons.Filled.Bolt
        else -> Icons.Filled.School
    }
}

private fun polygonFor(i: Int) = when (i) {
    0 -> MaterialShapes.Cookie6Sided
    1 -> MaterialShapes.Cookie9Sided
    2 -> MaterialShapes.Cookie12Sided
    3 -> MaterialShapes.SoftBurst
    4 -> MaterialShapes.Clover4Leaf
    else -> MaterialShapes.Flower
}

/** Fach-Symbol in einer expressiven Form (Form und Farbe hängen vom Fach ab). */
@Composable
fun SubjectBadge(name: String, size: Dp, modifier: Modifier = Modifier) {
    val h = name.trim().lowercase().hashCode() and 0x7fffffff
    val shape = polygonFor(h % 6).toShape()
    val cs = MaterialTheme.colorScheme
    val (bg, fg) = when ((h / 6) % 3) {
        0 -> cs.secondaryContainer to cs.onSecondaryContainer
        1 -> cs.tertiaryContainer to cs.onTertiaryContainer
        else -> cs.primaryContainer to cs.onPrimaryContainer
    }
    Box(
        modifier
            .size(size)
            .clip(shape)
            .background(bg),
        contentAlignment = Alignment.Center,
    ) {
        Icon(iconFor(name), null, tint = fg, modifier = Modifier.size(size * 0.5f))
    }
}
