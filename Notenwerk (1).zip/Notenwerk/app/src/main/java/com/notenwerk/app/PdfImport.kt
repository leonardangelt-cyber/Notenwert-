package com.notenwerk.app

import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ParsedGrade(val subject: String, val sem: Int, val kind: Int, val value: Double, val tendency: Int)

class PdfResult(val subjects: LinkedHashMap<String, MutableSet<Int>>, val grades: List<ParsedGrade>)

/** Liest den Text aus einer PDF (Textebene, keine Texterkennung). */
fun extractPdfText(ctx: Context, uri: Uri): String {
    PDFBoxResourceLoader.init(ctx.applicationContext)
    ctx.contentResolver.openInputStream(uri).use { ins ->
        requireNotNull(ins)
        PDDocument.load(ins).use { doc ->
            val st = PDFTextStripper()
            st.setSortByPosition(true)
            return st.getText(doc)
        }
    }
}

private val cellRe = Regex("^([1-6](?:[.,][0-9]{1,2})?)([+-])?$")

private fun parseCell(raw: String): List<Pair<Double, Int>> {
    val c = raw.trim()
    if (c.isEmpty() || c == "-") return emptyList()
    return c.split('/').mapNotNull { part ->
        val m = cellRe.find(part.trim()) ?: return@mapNotNull null
        val v = m.groupValues[1].replace(',', '.').toDouble()
        val t = when (m.groupValues[2]) {
            "+" -> 1
            "-" -> -1
            else -> 0
        }
        v to t
    }
}

/** Erkennt die Notenübersicht, die Notan als PDF exportiert. */
fun parseNotan(text: String): PdfResult {
    val subjects = LinkedHashMap<String, MutableSet<Int>>()
    val grades = mutableListOf<ParsedGrade>()
    var sem = 0
    val halfRe = Regex("^([12])\\.\\s*Halbjahr")
    for (raw in text.lines()) {
        val line = raw.replace('−', '-').replace('–', '-').replace(' ', ' ').trim()
        if (line.isEmpty()) continue
        val h = halfRe.find(line)
        if (h != null) {
            sem = h.groupValues[1].toInt(); continue
        }
        if (line.startsWith("Insgesamt")) {
            sem = 0; continue
        }
        if (sem == 0) continue
        val tok = line.split(Regex("\\s+"))
        if (tok.size < 5 || !tok[0].all { it.isDigit() }) continue
        val name = tok.subList(1, tok.size - 3).joinToString(" ")
        if (name.isBlank()) continue
        subjects.getOrPut(name) { mutableSetOf() }.add(sem)
        for ((v, t) in parseCell(tok[tok.size - 3])) grades.add(ParsedGrade(name, sem, 0, v, t))
        for ((v, t) in parseCell(tok[tok.size - 2])) grades.add(ParsedGrade(name, sem, 1, v, t))
    }
    return PdfResult(subjects, grades)
}

private fun gradeText(g: ParsedGrade): String {
    val base = if (g.value % 1.0 == 0.0) g.value.toInt().toString() else fmt(g.value)
    return base + when (g.tendency) {
        1 -> "+"
        -1 -> "-"
        else -> ""
    }
}

@Composable
fun ImportCard(vm: AppVM) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var result by remember { mutableStateOf<PdfResult?>(null) }
    var failed by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        busy = true; failed = false
        scope.launch {
            val r = withContext(Dispatchers.IO) {
                try {
                    parseNotan(extractPdfText(ctx, uri))
                } catch (_: Throwable) {
                    null
                }
            }
            busy = false
            if (r == null || r.subjects.isEmpty()) failed = true else result = r
        }
    }

    ContainerCard(t("Import"), Icons.Filled.Download) {
        Text(
            t("Notenübersicht aus Notan (PDF) einlesen."),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        FilledTonalButton(onClick = { picker.launch(arrayOf("application/pdf")) }, enabled = !busy) {
            Icon(Icons.Filled.Download, null)
            Spacer(Modifier.width(8.dp))
            Text(t("PDF importieren"))
        }
        if (failed) {
            Text(t("Keine Noten in der PDF erkannt."), color = MaterialTheme.colorScheme.error)
        }
    }

    result?.let { r ->
        AlertDialog(
            onDismissRequest = { result = null },
            title = { Text(t("Import prüfen")) },
            text = {
                Column(
                    Modifier
                        .height(320.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Text(tf("{0} Fächer, {1} Noten gefunden. Vorhandene Noten werden nicht doppelt angelegt.", r.subjects.size, r.grades.size))
                    Text(t("Schriftlich | mündlich"), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    r.subjects.keys.forEach { name ->
                        Column {
                            Text(name, fontWeight = FontWeight.SemiBold)
                            (1..2).forEach { s ->
                                val w = r.grades.filter { it.subject == name && it.sem == s && it.kind == 0 }.joinToString(", ") { gradeText(it) }
                                val o = r.grades.filter { it.subject == name && it.sem == s && it.kind == 1 }.joinToString(", ") { gradeText(it) }
                                if (w.isNotEmpty() || o.isNotEmpty()) {
                                    Text(
                                        tf("{0}. HJ {1}", s, "${w.ifEmpty { "–" }} | ${o.ifEmpty { "–" }}"),
                                        style = MaterialTheme.typography.bodyMedium,
                                    )
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { vm.importResult(r); result = null }) { Text(t("Importieren")) }
            },
            dismissButton = { TextButton(onClick = { result = null }) { Text(t("Abbrechen")) } },
        )
    }
}
