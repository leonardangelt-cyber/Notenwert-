@file:OptIn(ExperimentalLayoutApi::class)

package com.notenwerk.app

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.roundToInt

// ----------------------------------------------------------------- Warnung

@Composable
fun WarningBanner(text: String) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(MaterialTheme.colorScheme.errorContainer)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Filled.Warning, null, tint = MaterialTheme.colorScheme.onErrorContainer)
        Spacer(Modifier.width(12.dp))
        Text(text, color = MaterialTheme.colorScheme.onErrorContainer, style = MaterialTheme.typography.bodyLarge)
    }
}

// ----------------------------------------------------------------- Diagramm

@Composable
fun LineChart(avgs: List<Double>, dots: List<Double>?, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    val pts = GradeMode.points
    val lo = if (pts) noteEq(15.0) else 1.0
    val hi = if (pts) noteEq(0.0) else 6.0
    val grid = if (pts) listOf(15, 12, 9, 6, 3, 0).map { noteEq(it.toDouble()) to it.toString() }
    else (1..6).map { it.toDouble() to it.toString() }
    val lineColor = cs.primary
    val gridColor = cs.outlineVariant
    val textColor = cs.onSurfaceVariant.toArgb()
    val prog = remember { Animatable(0f) }
    LaunchedEffect(avgs.size, pts) {
        prog.snapTo(0f)
        prog.animateTo(1f, tween(900, easing = FastOutSlowInEasing))
    }
    Canvas(
        modifier
            .fillMaxWidth()
            .height(180.dp)
    ) {
        val left = 28.dp.toPx()
        val right = 8.dp.toPx()
        val top = 10.dp.toPx()
        val bottom = 10.dp.toPx()
        val w = size.width - left - right
        val h = size.height - top - bottom
        fun yOf(v: Double) = top + (((v - lo) / (hi - lo)).toFloat().coerceIn(0f, 1f)) * h
        val n = avgs.size
        fun xOf(i: Int) = left + if (n <= 1) w / 2 else w * i / (n - 1)

        val paint = android.graphics.Paint().apply {
            color = textColor
            textSize = 11.sp.toPx()
            isAntiAlias = true
            textAlign = android.graphics.Paint.Align.RIGHT
        }
        for ((v, label) in grid) {
            drawLine(gridColor, Offset(left, yOf(v)), Offset(size.width - right, yOf(v)), 1.dp.toPx())
            drawContext.canvas.nativeCanvas.drawText(label, left - 6.dp.toPx(), yOf(v) + 4.dp.toPx(), paint)
        }

        val path = Path()
        avgs.forEachIndexed { i, v ->
            val px = xOf(i)
            val py = yOf(v)
            if (i == 0) path.moveTo(px, py)
            else {
                val ox = xOf(i - 1)
                val oy = yOf(avgs[i - 1])
                val mx = (ox + px) / 2
                path.cubicTo(mx, oy, mx, py, px, py)
            }
        }
        clipRect(left = 0f, top = 0f, right = left + w * prog.value + 4f, bottom = size.height) {
            if (n >= 2) drawPath(path, lineColor, style = Stroke(3.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
        dots?.forEachIndexed { i, v ->
            if (i < n) drawCircle(gradeColor(v).copy(alpha = prog.value), 5.dp.toPx(), Offset(xOf(i), yOf(v)))
        }
        if (n >= 1) drawCircle(lineColor.copy(alpha = prog.value), 6.dp.toPx(), Offset(xOf(n - 1), yOf(avgs[n - 1])))
    }
}

@Composable
fun HistoryCard(vm: AppVM, s: Subject, sem: Int) {
    val h = vm.history(s, sem)
    if (h.size < 2) return
    ContainerCard(t("Verlauf"), Icons.Filled.ShowChart) {
        LineChart(h.map { it.second }, h.map { it.first })
        Text(
            t("Linie: laufender Schnitt, Punkte: einzelne Noten"),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
fun OverallHistoryCard(vm: AppVM, sem: Int) {
    val h = vm.overallHistory(sem)
    if (h.size < 2) return
    Column(Modifier.padding(vertical = 8.dp)) {
        ContainerCard(t("Verlauf"), Icons.Filled.ShowChart) {
            LineChart(h, null)
        }
    }
}

// ----------------------------------------------------------------- Planer

@Composable
fun PlannerCard(vm: AppVM, s: Subject, sem: Int) {
    val avg = vm.avg(s, sem)
    val pts = vm.pointMode
    val places = LocalDecimals.current
    var mode by rememberSaveable { mutableIntStateOf(0) }
    var kind by rememberSaveable { mutableIntStateOf(1) }
    var weight by rememberSaveable { mutableIntStateOf(1) }
    var tgt by rememberSaveable { mutableFloatStateOf(if (s.target > 0) s.target.toFloat() else 2.0f) }
    var sim by rememberSaveable { mutableFloatStateOf(2.0f) }

    fun toSlider(note: Float): Float = if (pts) pointsFromNote(note.toDouble()).toFloat() else note
    fun fromSlider(v: Float): Float = if (pts) noteEq(v.roundToInt().toDouble()).toFloat() else (v * 10f).roundToInt() / 10f
    val lo = if (pts) noteEq(15.0) else 1.0
    val hi = if (pts) noteEq(0.0) else 6.0

    ContainerCard(t("Planer"), Icons.Filled.TrendingUp) {
        if (s.finals.containsKey(sem)) {
            Text(t("Für dieses Halbjahr ist eine Note festgelegt."), color = MaterialTheme.colorScheme.onSurfaceVariant)
            return@ContainerCard
        }
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = mode == 0, onClick = withTap { mode = 0 }, label = { Text(t("Zielnote")) })
            FilterChip(selected = mode == 1, onClick = withTap { mode = 1 }, label = { Text(t("Was wäre wenn")) })
        }
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = kind == 0, onClick = withTap { kind = 0 }, label = { Text(t("schriftliche Noten")) })
            FilterChip(selected = kind == 1, onClick = withTap { kind = 1 }, label = { Text(t("mündliche Noten")) })
        }
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            (1..3).forEach { w ->
                FilterChip(selected = weight == w, onClick = withTap { weight = w }, label = { Text("${w}×") })
            }
        }

        if (mode == 0) {
            Text(
                tf("Zielnote: {0}", fmtGrade(tgt.toDouble(), if (pts) 0 else 1)),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
            )
            Slider(
                value = toSlider(tgt),
                onValueChange = { tgt = fromSlider(it) },
                onValueChangeFinished = { vm.setTarget(s.id, tgt.toDouble()) },
                valueRange = if (pts) 0f..15f else 1f..6f,
                steps = if (pts) 14 else 49,
            )
            val need = vm.neededGrade(s, sem, kind, weight, tgt.toDouble())
            val msg = when {
                need == null -> t("Diese Gruppe zählt 0 %. Ändere die Gewichtung unter „Gruppen“.")
                need < lo - 1e-6 -> t("Ziel nicht mehr erreichbar.")
                need >= hi - 1e-6 -> t("Ziel ist auf jeden Fall erreicht.")
                pts -> tf("Die nächste Note braucht mindestens {0} Punkte.", ceil(17.0 - 3.0 * need - 1e-9).toInt().coerceIn(0, 15))
                else -> tf("Die nächste Note darf höchstens eine {0} sein (genau: {1}).", floor(need + 1e-9).toInt().coerceIn(1, 6), fmt(need, 2))
            }
            Text(msg, style = MaterialTheme.typography.bodyLarge)
        } else {
            Text(
                tf("Angenommene Note: {0}", fmtGrade(sim.toDouble(), if (pts) 0 else 1)),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
            )
            Slider(
                value = toSlider(sim),
                onValueChange = { sim = fromSlider(it) },
                valueRange = if (pts) 0f..15f else 1f..6f,
                steps = if (pts) 14 else 49,
            )
            val newAvg = vm.avgWith(s, sem, kind, sim.toDouble(), weight)
            Row(verticalAlignment = Alignment.CenterVertically) {
                GradeBubble(newAvg, 64.dp)
                Spacer(Modifier.width(16.dp))
                Text(
                    tf("Schnitt: {0} → {1}", fmtGrade(avg, places), fmtGrade(newAvg, places)),
                    style = MaterialTheme.typography.titleMedium,
                )
            }
            Text(t("Die Note wird nur durchgerechnet und nicht gespeichert."), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        avg?.let {
            val z = if (pts) pointsFromNote(it).roundToInt() else it.roundToInt().coerceIn(1, 6)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Flag, null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(8.dp))
                Text(tf("Voraussichtliche Zeugnisnote: {0}", z), style = MaterialTheme.typography.bodyLarge)
            }
        }
    }
}

// ----------------------------------------------------------------- Alle Noten

@Composable
fun GradeList(vm: AppVM, s: Subject, sem: Int, onEdit: (Grade) -> Unit) {
    val list = vm.grades.filter { it.subjectId == s.id && it.sem == sem && it.kind != 3 }
        .sortedByDescending { it.date }
    if (list.isEmpty()) return
    val fmt = DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM).withLocale(I18n.locale)
    ContainerCard(t("Alle Noten"), Icons.Filled.ShowChart) {
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            list.forEach { g ->
                val color = gradeColor(vm.effective(g))
                val shape = RoundedCornerShape(16.dp)
                Row(
                    Modifier
                        .fillMaxWidth()
                        .bouncy(shape) { onEdit(g) }
                        .padding(vertical = 8.dp, horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(
                        Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(color),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                    ) {
                        Text(gradeLabel(g), color = onGrade(color), fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        val kindName = t(if (g.kind == 0) "schriftliche Noten" else "mündliche Noten")
                        Text(
                            if (g.weight > 1) "$kindName · ${g.weight}×" else kindName,
                            style = MaterialTheme.typography.titleSmall,
                        )
                        val date = if (g.date == 0L) "" else LocalDate.ofEpochDay(g.date).format(fmt)
                        val line = listOf(date, g.note).filter { it.isNotEmpty() }.joinToString(" · ")
                        if (line.isNotEmpty()) {
                            Text(line, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}
