-keepattributes *Annotation*
-keep class com.notenwerk.app.AppVM { *; }
-dontwarn javax.annotation.**

-keep class com.tom_roush.pdfbox.** { *; }
-dontwarn com.tom_roush.pdfbox.**
-dontwarn com.gemalto.jp2.**
-dontwarn org.bouncycastle.**
-dontwarn javax.xml.stream.**
